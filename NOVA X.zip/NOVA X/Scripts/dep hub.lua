--[[
This Roblox script works on:
Highschool Hoops Demo
Hoop Nations
RB World 4
Fight In A School
Gym League
Track & Field Infinite
Realistic Basketball
Hoop Journey
Emergency Response Liberty County
]]

loadstring(game:HttpGet("https://raw.githubusercontent.com/DepHubHolder/DepHub1/main/Loader1"))()